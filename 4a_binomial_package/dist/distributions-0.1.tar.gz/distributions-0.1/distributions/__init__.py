from .Generaldistribution import Distribution
from .Gaussiandistribution import Gaussian
from .Binomialdistribution import Binomial